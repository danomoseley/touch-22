Visit http://nuigroup.com/touchlib

Click Config.bat [To setup your screen] 
Click Server.bat [Runs FLOSC]
Click Vision.bat [Runs OSC.exe]
Open the "Clients Folder" and choose a client to test

This is not actual readme, please stand by for updated version.

Please submit any bugs on the forums.

http://nuigroup.com/forums/
