#!/bin/sh
java -jar FlashOSC.jar 3333 3000

